测试点不包含单条指令测试，只包含冲突序列的测试

testpoint0:
  针对jal，jr，jalr进行的测试，也包含部分P6指令集里的其他指令
testpoint 1~100：
  针对除了jal,jr,jalr之外的其他指令进行的测试